# -*- coding: utf-8 -*-
"""
Created on Fri Nov 18 15:59:11 2022

@authors:
Shashank Chikara |  schikara@andrew.cmu.edu
Jennifer B Liu | jbistafa@andrew.cmu.edu
Jing Cao  | jingc2@andrew.cmu.edu
Dhruv Dixit  | dhruvdix@andrew.cmu.edu
Yingqian Wang | yingqian@andrew.cmu.edu
"""

#CODE DESCRIPTION: this code extracts and clean Median_Income and Total_Pop information
# data from the US Census website. The data is extracted through an API and
# is outputed in csv format.

#CODE STARTS HERE:

#Request to import http API, pandas, and re for data manipulation
import requests
import pandas as pd
import re
def import_data():
    #Import Median Income by Place
    ## Variables listing
    key = 'b72bf10e7e3e69027e613d05601ea862f3f7ac36'
    name = 'S1901_C01_012E'
    table = 'data/2021/acs/acs1/subject'
    ## URL extraction
    url = f'https://api.census.gov/{table}?get=NAME,{name}&for=place:*&in=state:*&key={key}'
    median_income = requests.request('GET',url)
    def json_to_dataframe(median_income):
        return pd.DataFrame(median_income.json()[1:],columns=median_income.json()[0])
    ##Cleaning data: Split, remove, and add columns to the dataframe
    median_df = json_to_dataframe(median_income)
    median_df[['City','State']] = median_df.NAME.apply(lambda x: pd.Series(str(x).split(", ")))
    median_df.NAME.apply(lambda x: pd.Series(str(x).split(",")))
    del median_df['state'], median_df['place'], median_df['NAME']
    median_df = median_df.rename(columns={"S1901_C01_012E": "Median_Income"})
    ##Cleaning data: Remove " city" or " CDP" or " zona urbana" from "City" column rows
    pat = r' city'
    for row in range(len(median_df)):
        if re.search(pat, median_df.loc[row][1]) != None:
            median_df.loc[row][1] = median_df.loc[row][1].replace(pat, '')
    pat = r' CDP'
    for row in range(len(median_df)):
        if re.search(pat, median_df.loc[row][1]) != None:
            median_df.loc[row][1] = median_df.loc[row][1].replace(pat, '')
    pat = r' zona urbana'
    for row in range(len(median_df)):
        if re.search(pat, median_df.loc[row][1]) != None:
            median_df.loc[row][1] = median_df.loc[row][1].replace(pat, '')
    ##Cleaning data: removing special characters in city name
    pat = r'\.'
    for row in range(len(median_df)):
        if re.search(pat, median_df.loc[row][1]) != None:
            median_df.loc[row][1] = median_df.loc[row][1].replace('.', '')
    pat = '\''
    for row in range(len(median_df)):
        if re.search(pat, median_df.loc[row][1]) != None:
            median_df.loc[row][1] = median_df.loc[row][1].replace(pat, ' ')
    ##Copy table to csv file
    with open(r'median_income.csv','w', newline='') as f:
        median_df.to_csv(f)

    #Import Population by Place
    ## Variables listing
    key = 'b72bf10e7e3e69027e613d05601ea862f3f7ac36'
    name = 'S0101_C01_001E'
    table = 'data/2021/acs/acs1/subject'
    ## URL extraction
    url = f'https://api.census.gov/{table}?get=NAME,{name}&for=place:*&in=state:*&key={key}'
    pop_total = requests.request('GET',url)
    def json_to_dataframe(pop_total):
        return pd.DataFrame(pop_total.json()[1:],columns=pop_total.json()[0])
    ##Cleaning data: Split, remove, and add columns to the dataframe
    pop_df = json_to_dataframe(pop_total)
    pop_df[['City','State']] = pop_df.NAME.apply(lambda x: pd.Series(str(x).split(", ")))
    pop_df.NAME.apply(lambda x: pd.Series(str(x).split(",")))
    del pop_df['state'], pop_df['place'], pop_df['NAME']
    pop_df = pop_df.rename(columns={"S0101_C01_001E": "Population_Total"})
    ##Cleaning data: Remove " city" or " CDP" or " zona urbana" from "City" column rows
    pat = r' city'
    for row in range(len(pop_df)):
        if re.search(pat, pop_df.loc[row][1]) != None:
            pop_df.loc[row][1] = pop_df.loc[row][1].replace(pat, '')
    pat = r' CDP'
    for row in range(len(pop_df)):
        if re.search(pat, pop_df.loc[row][1]) != None:
            pop_df.loc[row][1] = pop_df.loc[row][1].replace(pat, '')
    pat = r' zona urbana'
    for row in range(len(pop_df)):
        if re.search(pat, pop_df.loc[row][1]) != None:
            pop_df.loc[row][1] = pop_df.loc[row][1].replace(pat, '')
    ##Cleaning data: removing special characters in city name
    pat = r'\.'
    for row in range(len(pop_df)):
        if re.search(pat, pop_df.loc[row][1]) != None:
            pop_df.loc[row][1] = pop_df.loc[row][1].replace('.', '')
    pat = '\''
    for row in range(len(pop_df)):
        if re.search(pat, pop_df.loc[row][1]) != None:
            pop_df.loc[row][1] = pop_df.loc[row][1].replace(pat, ' ')
    with open(r'pop_total.csv','w', newline='') as f:
       pop_df.to_csv(f)