"""
Created on Tue Nov 29 23:24:39 2022

@authors:
Shashank Chikara |  schikara@andrew.cmu.edu
Jennifer B Liu | jbistafa@andrew.cmu.edu
Jing Cao  | jingc2@andrew.cmu.edu
Dhruv Dixit  | dhruvdix@andrew.cmu.edu
Yingqian Wang | yingqian@andrew.cmu.edu
"""
from bs4 import BeautifulSoup
from urllib.request import urlopen
import requests
import csv


def comp_details(compname):
    num_reviews = 5
    url_overview = f"https://www.careerbliss.com/{compname}/"
    url_reviews = f"https://www.careerbliss.com/{compname}/reviews/"
    response_headcount = requests.get(url_overview)
    soup_headcount = BeautifulSoup(response_headcount.text, "html.parser")
    soup_headcount.prettify()
    # get headcount
    major_info_strong = soup_headcount.find_all('td')
    company_size_condensed="N/A"
    for line in major_info_strong:
        if line.text[0:13] == "Company Size:":
            company_size = line.text[14:]
            for i in range(len(company_size)):
                if company_size[i] == " ":
                    company_size_condensed = company_size[:i - 2]
    company_headcount = company_size_condensed

    response_reviews = requests.get(url_reviews)
    soup_reviews = BeautifulSoup(response_reviews.text, "html.parser")

    # get ratings
    overall_rating = 'N/A'
    salary = 'N/A'

    ratings = soup_reviews.find_all('p')
    for line in ratings:
        if "has an overall rating of" in line.text:
            overall_rating = line.text[9 + len(compname) + 26:9 + len(compname) + 29]
        if "employees earn" in line.text:
            salary_temp = line.text[9 + len(compname) + 16:]
            for i in range(len(salary_temp)):
                if salary_temp[i] == ' ':
                    salary = salary_temp[:i]
                    break
    # get reviews
    reviews = soup_reviews.find_all('p', {"class": "comments foggy"})
    reviews_condensed = []
    for item in reviews:
        if len(reviews_condensed) == int(num_reviews):
            break
        reviews_condensed.append(item.text)
    reviews = reviews_condensed
    return ([company_headcount, overall_rating, salary, reviews])
