# -*- coding: utf-8 -*-
"""
Created on Sat Dec  3 10:26:10 2022

@authors:
Shashank Chikara |  schikara@andrew.cmu.edu
Jennifer B Liu | jbistafa@andrew.cmu.edu
Jing Cao  | jingc2@andrew.cmu.edu
Dhruv Dixit  | dhruvdix@andrew.cmu.edu
Yingqian Wang | yingqian@andrew.cmu.edu
"""

import pandas as pd
import numpy as np


# Livability score defined as sum of criteria weights * normalized city variable:
# weight_density * (city_density - density_min) / (density_max -density_min) +
# weight_median_income * (median_income - median_income_min) / (median_income_max - median_income_min) +
# weight_home_value * (home_value - home_value_min) / (home_value_max - home_value_min) +
# weight_crime_rate * (1-(crime_rate - crime_rate_min) / (crime_rate_max - crime_rate_min))

def livability_score_calc(
        city_density,
        in_median_income,
        in_home_value,
        in_crime_rate):
    # Module that collects user criteria rank to define criteria weight for the livability score

    # Weight by importance:
    # 1st most important = 40%
    # 2nd most important = 30%
    # 3rd most important = 20%
    # 4th most important = 10%
    # weight formula: 0.1*(5 - rank)

    confirmation = False
    weight_density =1
    weight_median_income =1
    weight_home_value =1
    weight_crime_rate =1
    while confirmation == False:

        print('Please enter ranking for each city criteria (Density, Median Income, Home Value, Crime Rate)\n'
              'from 1 to 4 without repetition (1-Most important, 2-2nd most important, 3-3rd most important, 4-Least important)')
        # Prompt user to enter rank
        weight_density = input('Please enter a rank for Density: ')
        # Validate user input
        ranks = ['1', '2', '3', '4']
        while weight_density not in ranks:
            print(f'Only enter a valid rank ({ranks})')
            weight_density = input('Please enter a valid rank: ')

        # Prompt user to enter rank
        weight_median_income = input('Please enter a rank for Median Income: ')
        # Validate user input
        ranks.remove(weight_density)
        while weight_median_income not in ranks:
            print(f'Only enter a valid rank ({ranks})')
            weight_median_income = input('Please enter a valid rank: ')

        # Prompt user to enter rank
        weight_home_value = input('Please enter a rank for Home Value: ')
        # Validate user input
        ranks.remove(weight_median_income)
        while weight_home_value not in ranks:
            print(f'Only enter a valid rank ({ranks})')
            weight_home_value = input('Please enter a valid rank: ')

        # Prompt user to enter rank
        ranks.remove(weight_home_value)
        weight_crime_rate = ranks[0]
        print('Rank for Crime Rate is:', weight_crime_rate)

        # Output user ranking
        print('Your overall ratings are:')
        print('Density:', weight_density)
        print('Median Income:', weight_median_income)
        print('Home Value:', weight_home_value)
        print('Crime Rate:', weight_crime_rate)

        confirm = input('Type y to confirm ranking or n to redo ranking: ')
        while confirm not in 'yn':
            input('Enter a valid confirmation(y or n): ')

        if confirm == 'y':
            confirmation = True

            # Assigning weight to variables
    weight_density = 0.1 * (5 - int(weight_density))
    weight_median_income = 0.1 * (5 - int(weight_median_income))
    weight_home_value = 0.1 * (5 - int(weight_home_value))
    weight_crime_rate = 0.1 * (5 - int(weight_crime_rate))
    # Module to calculate normalization factors of livability parameters
    # Normalization: Linear scalling: x = (x − x min)/(x max − x min )

    # Density
    ##Read file
    #    density_file = 'density.csv'
    #    density = pd.read_csv(density_file, index_col=(0),header=0, encoding='latin-1')
    ##Collects min and max values
    #    density = np.array(density['Density'])
    #    density_min = np.min(density)
    #    density_max = np.max(density)
    density_min = 1.28
    density_max = 57116

    # Median income
    ##Read median_income csv file
    median_income_file = 'median_income.csv'
    median_df = pd.read_csv(median_income_file, index_col=(0), header=0, encoding='latin-1')
    ##Collects min and max values
    median_income = np.array(median_df['Median_Income'])
    median_income_min = np.min(median_income)
    median_income_max = np.max(median_income)

    # Home value
    ##Read file
    homevalue_file = 'HomeValue.xlsx'
    home_value = pd.read_excel(homevalue_file, index_col=(0), header=0)
    ##Collects min and max values
    home_value = np.array(home_value['HomePrice'])
    home_value_min = np.min(home_value)
    home_value_max = np.max(home_value)

    # Crime rate
    ##Read file
    crimerate_file = 'CrimeRate.xlsx'
    crime_rate = pd.read_excel(crimerate_file, index_col=(0), header=0)
    ##Collects min and max values
    crime_rate = np.array(crime_rate['Vcrime'])
    crime_rate_min = np.min(crime_rate)
    crime_rate_max = np.max(crime_rate)

    if crime_rate_min =="":
        crime_rate_min=1
    if crime_rate_max =="":
        crime_rate_max=2
    if in_crime_rate =="":
        in_crime_rate=3

    livability_score = (
        float((weight_density * (city_density - density_min) / (density_max - density_min)))+
        float((weight_median_income * (in_median_income - median_income_min) / (median_income_max - median_income_min))) +
        float((weight_home_value * (in_home_value - home_value_min) / (home_value_max - home_value_min)))
    )

    return float(livability_score)*100