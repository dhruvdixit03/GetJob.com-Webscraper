#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Nov 17 18:38:58 2022

@authors:
Shashank Chikara |  schikara@andrew.cmu.edu
Jennifer B Liu | jbistafa@andrew.cmu.edu
Jing Cao  | jingc2@andrew.cmu.edu
Dhruv Dixit  | dhruvdix@andrew.cmu.edu
Yingqian Wang | yingqian@andrew.cmu.edu

"""
import requests
from bs4 import BeautifulSoup
import re
from pyfiglet import Figlet
import company_sp_datascrapper as md1
import us_census_api_and_cleaning as md2
import location_stats_builder as mod3
import clean_data as clean_d
import livability_score as ls
import pandas as pd
from texttable import Texttable
import numpy as np
import plotext
import warnings
#Suppress warnings if any
warnings.filterwarnings('ignore')

# Function to display Progress Bar
def progressbar (progress, elements):
    perc = 100 * (progress/float(elements))
    length = 100
    filledLength = int(length * progress // elements)
    bar = '█' * filledLength + '-' * (length - filledLength)
    print(f"\r|{bar}|{perc:.2f}%", end="\r")

# Function to scrape Job postings from linkedin
def linkedin_scraper(webpage, page_number):
    next_page = webpage + str(page_number)
    #print(str(next_page))
    response = requests.get(str(next_page))
    soup = BeautifulSoup(response.content,'html.parser')
# Main Job search function
def job_search():
    f = Figlet(font='slant')
    print (f.renderText('GET JOB . COM'))
    print("----------------------------------")
    print(" Let's help you find a job")
    print("----------------------------------")
    # User to enter the job title
    Job_title = input("Enter your desired job title:   ")
    jt = Job_title.replace(" ", "%20")
    # User to enter the Job location to be searched for
    Job_loc = input("Enter a Location to search:    ")
    jl = Job_loc.replace(" ", "%20")

    print("\nSit tight while we retrieve the top jobs for you !!!\n")
    #Show initial Progress bar at 0%
    progressbar(0,1)
    # Import US Census Data
    md2.import_data()
    # Clean Data obtained from FBI, Zillow etc.
    clean_d.clean()
    # Initialize static pages to be searched
    page_number=2
    # Build URL to be scrapped
    url = f"https://www.linkedin.com/jobs-guest/jobs/api/seeMoreJobPostings/search?keywords={jt}&location={jl}&trk=public_jobs_jobs-search-bar_search-submit&position=1&pageNum=0&start=0"
    response = requests.get(url)
    # Parse the response
    soup = BeautifulSoup(response.content,'html.parser')
    # Main list to hold job posting details
    reclc = []
    # list to hold days since job posted details of all job postings
    job_posted_days = []
    # Holds jpb ids to be plotted against the days since job posted
    jpd_job_id = []
    # Increase the page numbers for the search
    if page_number < 50:
        page_number = page_number + 50
        # Call the job scraping function
        linkedin_scraper(url, page_number)
    # Search the job cards from the response
    jobs = soup.find_all('div', class_='base-card relative w-full hover:no-underline focus:no-underline base-card--link base-search-card base-search-card--link job-search-card')
    # Define column for the job details dataframe
    columns=['Job Title','Company','Location','Salary', 'Posted', 'Job Link' , 'Company Ratings', 'No of Employees', 'Average Salary', 'Reviews',
             "Location Crime Rate", "Location Average Home Value $", "Location Total Population" , "Location Total Land Area", "Location Median Income",
             "US Median Crime Rate", "US Median Home Value", "US Median Income"]
    # Initialize counter as zero
    ctr = 0
    tot_ctr=1
    # Check the number of jobs from the scrapped response
    if len(jobs) !=0:
        tot_ctr = len(jobs)
    else:
        print("Please Enter the correct Job Title and Location")
        job_search()
    # Iterate through all the jobs to get the respective details
    for job in jobs:
        job_title = job.find('h3', class_='base-search-card__title').text.strip()
        job_company = job.find('h4', class_='base-search-card__subtitle').text.strip()
        job_location = job.find('span', class_='job-search-card__location').text.strip()
        jc = job_company.replace(" ", "-")
        # Make a call to module 1 to obtain company specific details to be used as shown below
        mlist = md1.comp_details(jc)
        cmp_rating = mlist[1]
        cmp_headcount = mlist[0]
        cmp_avg_sal = mlist[2]
        cmp_reviews = mlist[3]
        loc_city_state = job_location.strip().split(',')
        loc_c = loc_city_state[0]
        try:
            loc_s = loc_city_state[1]
        except:
            loc_s = ("")
        # Obtain location specific statistics from module 3
        cm_stats = mod3.ret_data([loc_c,loc_s])
        loc_crime_rt = cm_stats[0]
        loc_avg_home_val =cm_stats[1]
        loc_tot_pop =cm_stats[2]
        loc_land_area =cm_stats[3]
        loc_med_inc=cm_stats[4]
        med_crime_rt=cm_stats[5]
        med_home_val=cm_stats[6]
        median_med_incom = cm_stats[7]
        # Take appropriate action when salary and job posting time is not available
        if job.find('span', class_='job-search-card__salary-info') :
            js = job.find('span', class_='job-search-card__salary-info').text.strip()
            job_salary = js.replace("\n", "")
            re.sub('\\s+',' ',job_salary)
        else:
            job_salary = "N/A"
        if job.find('time', class_='job-search-card__listdate'):
            job_time = job.find('time', class_='job-search-card__listdate').text.strip()
        else:
            job_time = "N/A"
        # Logic to convert months and weeks to days
        if re.search("month", job_time) != None:
            temp = re.findall(r'\d+', job_time)
            job_posted_days.append(int(temp[0]) * 30)
            jpd_job_id.append(ctr)

        elif re.search("week", job_time) != None:
            temp = re.findall(r'\d+', job_time)
            job_posted_days.append(int(temp[0]) * 7)
            jpd_job_id.append(ctr)
        elif re.search("days", job_time) != None:
            temp = re.findall(r'\d+', job_time)
            job_posted_days.append(int(temp[0]))
            jpd_job_id.append(ctr)

        job_link = job.find('a', class_='base-card__full-link')['href']
        ctr+=1
        # Show progerss bar updates
        progressbar(ctr,tot_ctr)
        # Append the job details to main list
        reclc.append([job_title,job_company,job_location,job_salary,job_time,job_link,cmp_rating,cmp_headcount,cmp_avg_sal,cmp_reviews,
                      loc_crime_rt,loc_avg_home_val,loc_tot_pop,loc_land_area,loc_med_inc,med_crime_rt,med_home_val,median_med_incom])
    # Make a DF for all the scrapped jobs
    df = pd.DataFrame(reclc)
    df.columns = columns

    # Display all the jobs
    with pd.option_context('display.max_rows', None,
                           'display.max_columns', 5,
                           'display.precision', 3,
                           'display.width', 1000,
                           ):
        print("\n\n",df.iloc[:, : 5])
    # Create a Menu for End user
    while True:
        print("\nMenu")
        print("----------------------------------------------------------------")
        print(" - Enter the Job Id to get more details")
        print(" - Enter m to go to search for another job title / location")
        print(" - Enter l to calculate livability score of the location")
        print(" - Enter b to go to the search results")
        print(" - Enter q to exit")
        print("----------------------------------------------------------------\n")
        # Ask userr for the input
        choice1 = (input("Enter the Choice:"))
        # Take action on the user input
        if choice1=="m":
            job_search()
        elif choice1 =="b":
                with pd.option_context('display.max_rows', None,
                           'display.max_columns', 5,
                           'display.precision', 3,
                           'display.width', 1000,
                           ):
                    print("\n\n",df.iloc[:, : 5])

        elif choice1 =="q":
            exit(0)
        elif choice1 == "l":
            jid_inp = (input("\nEnter the Job ID to calculate the livability score:"))
            lst = df.iloc[int(jid_inp)].tolist()
            print("The Livability score is ",ls.livability_score_calc(float(lst[12])/float(lst[13]),lst[14],lst[11],lst[10]))
        else:
            try:
                if int(choice1)<len(jobs):
                    f = Figlet(font='colossal')
                    print(f.renderText('\nJOB DETAILS:'))
                    lst = df.iloc[int(choice1)].tolist()
                    t = Texttable()
                    # Show job details as a single table
                    t.add_rows([['Attributes', 'Data / Values'],
                                ['Job Title', lst[0]],['Company', lst[1]],
                                ['Location', lst[2]],['Salary', lst[3]],['Posted', lst[4]],
                                ['Company Ratings', lst[6]], ['Headcount', lst[7]],
                                ['Avg. Salary at Company (USD)', lst[8]],['Location Crime Rate', lst[10]],
                                ['Location Average Home Value (USD)', lst[11]],
                                ['Location Total Population', lst[12]], ['Location Total Land Area (Sq.M)', lst[13]],
                                ['Location Population Density', float(lst[12])/float(lst[13])],
                                ['Location Median Income (USD)', lst[14]],
                                ['Job Link', lst[5]]])

                    print(t.draw())
                    # Plot stats with respect to specific job
                    plotext.subplots(2, 2)
                    plotext.plot_size(100,100)
                    plotext.subplot(1,1)
                    plotext.title("Crime Rate")
                    xval = ["US (Avg.)", "Job Location"]
                    yval = [lst[15],lst[10]]
                    plotext.bar(xval,yval)

                    plotext.subplot(1,2)
                    plotext.title("Avg. Home Value (USD)")
                    xval = ["US (Median)", "Job Location"]
                    yval = [lst[16], lst[11]]
                    plotext.bar(xval, yval)

                    plotext.subplot(2,1)
                    plotext.title("Income (USD)")
                    xval = ["US (Median)", "Job Location"]
                    yval = [lst[17], lst[14]]
                    plotext.bar(xval, yval)

                    plotext.subplot(2,2)
                    plotext.title("Job ID vs Days Since job posted")
                    student = np.random.normal(14,5,100)
                    xval = jpd_job_id
                    yval = job_posted_days
                    plotext.bar(xval, yval)
                    plotext.show()
                    # Display Reviews if available
                    if len(lst[9]) != 0:
                        print("-- Company Reviews --\n")
                        for i in lst[9]:
                            print("-ººº-", i)

                else:
                    print("---> Enter the correct Job ID or menu option")
            except:
                print("---> Enter the correct Job ID or menu option")
#Start of the main module
job_search()