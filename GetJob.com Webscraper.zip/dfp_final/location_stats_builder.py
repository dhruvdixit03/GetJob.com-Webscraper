# -*- coding: utf-8 -*-
"""
Created on Tue Nov 29 21:58:59 2022

@authors:
Shashank Chikara |  schikara@andrew.cmu.edu
Jennifer B Liu | jbistafa@andrew.cmu.edu
Jing Cao  | jingc2@andrew.cmu.edu
Dhruv Dixit  | dhruvdix@andrew.cmu.edu
Yingqian Wang | yingqian@andrew.cmu.edu
"""

import pandas as pd
import re
import census_stats_builder as md4


def ret_data(input):
    CrimeRate = "CrimeRate.xlsx"
    HomeValue = "HomeValue.xlsx"
    LandArea = "LandArea.xlsx"

    # reading excel files
    fd_CrimeRate = pd.read_excel(CrimeRate)
    fd_HomeValue = pd.read_excel(HomeValue)
    fd_LandArea = pd.read_excel(LandArea)

    us_state_to_abbrev = {
        "Alabama": "AL",
        "Alaska": "AK",
        "Arizona": "AZ",
        "Arkansas": "AR",
        "California": "CA",
        "Colorado": "CO",
        "Connecticut": "CT",
        "Delaware": "DE",
        "Florida": "FL",
        "Georgia": "GA",
        "Hawaii": "HI",
        "Idaho": "ID",
        "Illinois": "IL",
        "Indiana": "IN",
        "Iowa": "IA",
        "Kansas": "KS",
        "Kentucky": "KY",
        "Louisiana": "LA",
        "Maine": "ME",
        "Maryland": "MD",
        "Massachusetts": "MA",
        "Michigan": "MI",
        "Minnesota": "MN",
        "Mississippi": "MS",
        "Missouri": "MO",
        "Montana": "MT",
        "Nebraska": "NE",
        "Nevada": "NV",
        "New Hampshire": "NH",
        "New Jersey": "NJ",
        "New Mexico": "NM",
        "New York": "NY",
        "North Carolina": "NC",
        "North Dakota": "ND",
        "Ohio": "OH",
        "Oklahoma": "OK",
        "Oregon": "OR",
        "Pennsylvania": "PA",
        "Rhode Island": "RI",
        "South Carolina": "SC",
        "South Dakota": "SD",
        "Tennessee": "TN",
        "Texas": "TX",
        "Utah": "UT",
        "Vermont": "VT",
        "Virginia": "VA",
        "Washington": "WA",
        "West Virginia": "WV",
        "Wisconsin": "WI",
        "Wyoming": "WY",
        "District of Columbia": "DC",
        "American Samoa": "AS",
        "Guam": "GU",
        "Northern Mariana Islands": "MP",
        "Puerto Rico": "PR",
        "United States Minor Outlying Islands": "UM",
        "U.S. Virgin Islands": "VI",
        "Puerto Rico": "Puerto"
    }

    # invert the dictionary
    abbrev_to_us_state = dict(map(reversed, us_state_to_abbrev.items()))
    Input = input # Test
    city = Input[0]
    state = ""
    if Input[1] != "":
        try:
            statewt = Input[1].strip()
            state = abbrev_to_us_state[statewt.strip()]
        except:
            state=""
    #state = Input[1]
    # Output = [Crime rate , Average home value, Total population , Land area , Median income,
    #            crime rate-us median,home value - US median, income-US median ]
    Output = [0, 0, 0, 0, 0, 321.9, 212226.9, 70784]

    ###########################################################################
    # If ONLY city data are available
    if Input[0] != "" and Input[1] == "":
        #    substring = Input[0]
        #    fd_Crime_Found = fd_CrimeRate[fd_CrimeRate.apply(lambda row: row.astype(str).str.contains(substring, case=False).any(), axis=1)]

        #    size =fd_Crime_Found.shape
        #    if size[0] = 0: # Data for this city is NOT available
        #    Output = ["NotAvailable"]

        ##########################################################
        # Find the crime rate  by matching city name only (get the last match)
        for row in range(len(fd_CrimeRate)):
            if re.search(city, fd_CrimeRate.iloc[row]['City']) != None:
                Output[0] = fd_CrimeRate.iloc[row]['Vcrime']
                # print( Output[0])
        ##########################################################
        # Find the home value  by matching city and state name
        for row in range(len(fd_HomeValue)):
            if re.search(city, fd_HomeValue.iloc[row]['City']) != None:
                Output[1] = fd_HomeValue.iloc[row]['HomePrice']
                # print( Output[1])
        ##########################################################
        # Find the land area by matching city and state name
        for row in range(len(fd_LandArea)):
            if re.search(city, fd_LandArea.iloc[row]['City']) != None:
                Output[3] = fd_LandArea.iloc[row]['LandArea']
                # print( Output[3])

    ###########################################################################
    # If both city and state data are available
    if Input[0] != "" and Input[1] != "":
        #    substring = Input[0]
        #    fd_Crime_Found = fd_CrimeRate[fd_CrimeRate.apply(lambda row: row.astype(str).str.contains(substring, case=False).any(), axis=1)]

        #    size =fd_Crime_Found.shape
        #    if size[0] = 0: # Data for this city is NOT available
        #    Output = ["NotAvailable"]

        ##########################################################
        # Find the crime rate  by matching city and state name
        for row in range(len(fd_CrimeRate)):
            if re.search(city, fd_CrimeRate.iloc[row]['City']) != None and re.search(state, fd_CrimeRate.iloc[row][
                'State']) != None:
                Output[0] = fd_CrimeRate.iloc[row]['Vcrime']
                # print( Output[0])
        ##########################################################
        # Find the home value  by matching city and state name
        for row in range(len(fd_HomeValue)):
            if re.search(city, fd_HomeValue.iloc[row]['City']) != None and re.search(state, fd_HomeValue.iloc[row][
                'State']) != None:
                Output[1] = fd_HomeValue.iloc[row]['HomePrice']
                # print( Output[1])
        ##########################################################
        # Find the land area by matching city and state name
        for row in range(len(fd_LandArea)):
            if re.search(city, fd_LandArea.iloc[row]['City']) != None and re.search(state, fd_LandArea.iloc[row][
                'State']) != None:
                Output[3] = fd_LandArea.iloc[row]['LandArea']
                # print( Output[3])

    ###########################################################################
    # If only state data is available, average the data:
    if Input[0] == "" and Input[1] != "":
        # print("only state available")
        temp_c = 0
        count_c = 0
        temp_h = 0
        count_h = 0
        temp_l = 0
        count_l = 0
        ##########################################################
        # Find the crime rate by matching state name
        for row in range(len(fd_CrimeRate)):
            if re.search(state, fd_CrimeRate.iloc[row]['State']) != None:
                temp_c = fd_CrimeRate.iloc[row]['Vcrime'] + temp_c
                count_c = count_c + 1
                # print(temp_c)
                # print(count_c)
        Output[0] = temp_c / count_c
        ##########################################################
        # Find the home value by matching state name
        for row in range(len(fd_HomeValue)):
            if re.search(state, fd_HomeValue.iloc[row]['State']) != None:
                temp_h = fd_HomeValue.iloc[row]['HomePrice'] + temp_h
                count_h = count_h + 1
                print(temp_h)
                print(count_h)
        Output[1] = temp_h / count_h
        ##########################################################
        # Find the land area by matching state name
        for row in range(len(fd_LandArea)):
            if re.search(state, fd_LandArea.iloc[row]['State']) != None:
                temp_l = fd_LandArea.iloc[row]['LandArea'] + temp_l
                count_l = count_l + 1
            # print(temp_h)
            # print(count_h)
        Output[3] = temp_l / count_l
    dmz = md4.get_census_info_for_city_state([city, state], "median_income.csv", "pop_total.csv")
    Output[4] = dmz[0]
    Output[2] = dmz[1]
    return Output