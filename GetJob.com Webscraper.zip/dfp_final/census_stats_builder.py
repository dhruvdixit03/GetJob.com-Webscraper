# -*- coding: utf-8 -*-
"""
Created on Tue Nov 29 23:24:39 2022

@authors:
Shashank Chikara |  schikara@andrew.cmu.edu
Jennifer B Liu | jbistafa@andrew.cmu.edu
Jing Cao  | jingc2@andrew.cmu.edu
Dhruv Dixit  | dhruvdix@andrew.cmu.edu
Yingqian Wang | yingqian@andrew.cmu.edu
"""

# Import libraries
import pandas as pd
import re
import numpy as np


def get_census_info_for_city_state(city_state, median_income_file, population_file):
    # Declare default values
    median_income = 'NA'
    pop_total = 'NA'
    city = city_state[0]
    state = city_state[1]

    # Read median_income csv file
    median_df = pd.read_csv(median_income_file, index_col=(0), header=0, encoding='latin-1')

    # Find the median_income by matching city and state name
    for row in range(len(median_df)):
        if re.search(city, median_df.iloc[row]['City']) != None and re.search(state,
                                                                              median_df.iloc[row]['State']) != None:
            median_income = median_df.iloc[row]['Median_Income']

    # If doesnt find a match by city and state, calculate state info
    if median_income == 'NA':
        state_median_income = np.array([])
        for row in range(len(median_df)):
            if re.search(state, median_df.iloc[row]['State']) != None:
                state_median_income = np.append(state_median_income, median_df.iloc[row]['Median_Income'])
        median_income = np.median(state_median_income)

    # If doesnt find a match by city and state or state only, calculate city info (finds first city with match)
    if median_income == 'NA':
        for row in range(len(median_df)):
            if re.search(city, median_df.iloc[row]['City']) != None:
                median_income = median_df.iloc[row]['Median_Income']

    # Read population csv file
    pop_df = pd.read_csv(population_file, index_col=(0), header=0, encoding='latin-1')

    # Find the pop_total by matching city and state name
    for row in range(len(pop_df)):
        if re.search(city, pop_df.iloc[row]['City']) != None and re.search(state, pop_df.iloc[row]['State']) != None:
            pop_total = pop_df.iloc[row]['Population_Total']

    # If doesnt find a match by city and state, calculate state info
    if pop_total == 'NA':
        state_pop_total = np.array([])
        for row in range(len(pop_df)):
            if re.search(state, pop_df.iloc[row]['State']) != None:
                state_pop_total = np.append(state_pop_total, pop_df.iloc[row]['Population_Total'])
        pop_total = state_pop_total.sum()

    # If doesnt find a match by city and state or state only, calculate city info (finds first city with match)
    if pop_total == 'NA':
        for row in range(len(median_df)):
            if re.search(city, pop_df.iloc[row]['City']) != None:
                pop_total = pop_df.iloc[row]['Population_Total']

    # Combine variables in a single list
    output = [median_income, pop_total]
    return output

# def test_get_census_info():
#    #Read varible from the user
#    city_state = ['Chicago','Illinois']
#    output = get_census_info_for_city_state(city_state, 'median_income.csv', 'pop_total.csv')
#    print(output)








