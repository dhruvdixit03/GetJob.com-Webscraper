# -*- coding: utf-8 -*-
"""
Created on Sun Dec  4 16:37:03 2022
Clean the homevalue raw data of the current year
and save to cleaned excel file
@authors:
Shashank Chikara |  schikara@andrew.cmu.edu
Jennifer B Liu | jbistafa@andrew.cmu.edu
Jing Cao  | jingc2@andrew.cmu.edu
Dhruv Dixit  | dhruvdix@andrew.cmu.edu
Yingqian Wang | yingqian@andrew.cmu.edu
"""

import pandas as pd
import re

def clean():
    HomeValue1 = "raw_data/HomeValueRaw.csv"
    LandArea1 = "raw_data/LandAreaRaw.xlsx"
    CrimeRate1 = "raw_data/CrimeRateRaw.xls"

    # reading excel files
    # fd_CrimeRate = pd.read_excel(CrimeRate1)
    fd_HomeValue1 = pd.read_csv(HomeValue1)
    fd_LandArea1 = pd.read_excel(LandArea1)
    fd_CrimeRate1 = pd.read_excel(CrimeRate1)

    # Homevalue Raw Data Cleanup
    # Get averaged price for year 2022 and seperate city into a column
    fd_HV_New = fd_HomeValue1[
        ['RegionName', 'StateName', '1/31/2022', '2/28/2022', '3/31/2022', '4/30/2022', '5/31/2022', '6/30/2022',
         '7/31/2022', '8/31/2022', '9/30/2022', '10/31/2022']]
    fd_HV_New["HomePrice"] = fd_HomeValue1[
        ['1/31/2022', '2/28/2022', '3/31/2022', '4/30/2022', '5/31/2022', '6/30/2022', '7/31/2022', '8/31/2022',
         '9/30/2022', '10/31/2022']].mean(axis=1)
    fd_HV_New['City'] = fd_HV_New['RegionName'].str.split(',').str[0]

    # LandArea Raw Data Cleanup
    fd_LA_New = pd.DataFrame(columns=["State_abb", "City", "LandArea"])
    fd_LA_New[["State_abb", "City", "LandArea"]] = fd_LandArea1[['USPS', 'NAME', 'ALAND_SQMI']]
    # Remove " city" or " CDP" or " town" etc from data
    fd_LA_New1 = fd_LA_New.replace(regex=[' city| CDP| City| town| village| borough'], value='')

    # CrimeRate fill in empty cells in the first column and then remove not needed rows
    fd_CrimeRate1["Metropolitan Statistical Area"] = fd_CrimeRate1["Metropolitan Statistical Area"].ffill()
    fd_CrimeRate2 = fd_CrimeRate1[fd_CrimeRate1['Counties/principal cities'].str.startswith('Rate', na=False)]
    ##retain only city information
    fd_CrimeRate2['City'] = fd_CrimeRate2['Metropolitan Statistical Area'].str.split(',|-').str[0]

    fd_CrimeRate2['State1'] = fd_CrimeRate2['Metropolitan Statistical Area'].str.split(', ').str[1]
    fd_CrimeRate2['State2'] = fd_CrimeRate2['State1'].str.split(' ').str[0]
    fd_CrimeRate2['State'] = fd_CrimeRate2['State2'].str.split('-').str[0]
    # Save to new dataframe and rename the headers
    fd_CrimeRate3 = pd.DataFrame(columns=["State_abb", "City", "Vcrime"])
    fd_CrimeRate3[["State_abb", "City", "Vcrime"]] = fd_CrimeRate2[['State', 'City', 'Violent crime']]
    # Get the Violent Crime and Property Crime Data

    # Change state abbr. to state full spelling
    us_state_to_abbrev = {
        "Alabama": "AL",
        "Alaska": "AK",
        "Arizona": "AZ",
        "Arkansas": "AR",
        "California": "CA",
        "Colorado": "CO",
        "Connecticut": "CT",
        "Delaware": "DE",
        "Florida": "FL",
        "Georgia": "GA",
        "Hawaii": "HI",
        "Idaho": "ID",
        "Illinois": "IL",
        "Indiana": "IN",
        "Iowa": "IA",
        "Kansas": "KS",
        "Kentucky": "KY",
        "Louisiana": "LA",
        "Maine": "ME",
        "Maryland": "MD",
        "Massachusetts": "MA",
        "Michigan": "MI",
        "Minnesota": "MN",
        "Mississippi": "MS",
        "Missouri": "MO",
        "Montana": "MT",
        "Nebraska": "NE",
        "Nevada": "NV",
        "New Hampshire": "NH",
        "New Jersey": "NJ",
        "New Mexico": "NM",
        "New York": "NY",
        "North Carolina": "NC",
        "North Dakota": "ND",
        "Ohio": "OH",
        "Oklahoma": "OK",
        "Oregon": "OR",
        "Pennsylvania": "PA",
        "Rhode Island": "RI",
        "South Carolina": "SC",
        "South Dakota": "SD",
        "Tennessee": "TN",
        "Texas": "TX",
        "Utah": "UT",
        "Vermont": "VT",
        "Virginia": "VA",
        "Washington": "WA",
        "West Virginia": "WV",
        "Wisconsin": "WI",
        "Wyoming": "WY",
        "District of Columbia": "DC",
        "American Samoa": "AS",
        "Guam": "GU",
        "Northern Mariana Islands": "MP",
        "Puerto Rico": "PR",
        "United States Minor Outlying Islands": "UM",
        "U.S. Virgin Islands": "VI",
        "Puerto Rico": "Puerto"
    }

    # invert the dictionary
    abbrev_to_us_state = dict(map(reversed, us_state_to_abbrev.items()))

    # Change State Format to be consistent
    fd_HV_New['State'] = fd_HV_New['StateName'].map(abbrev_to_us_state)
    fd_HV_Final = fd_HV_New[['City', 'State', 'HomePrice']]
    #
    fd_LA_New1['State'] = fd_LA_New1['State_abb'].map(abbrev_to_us_state)
    fd_LA_Final = fd_LA_New1[['City', 'State', 'LandArea']]
    #
    fd_CrimeRate3['State'] = fd_CrimeRate3['State_abb'].map(abbrev_to_us_state)
    fd_CR_Final = fd_CrimeRate3[["City", "State", "Vcrime"]]
    # Print to new .csv file
    fd_HV_Final.to_excel('HomeValue.xlsx')
    fd_LA_Final.to_excel('LandArea.xlsx')
    fd_CR_Final.to_excel('CrimeRate.xlsx')